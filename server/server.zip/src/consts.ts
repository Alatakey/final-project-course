export const PI: number = 3.14;

export const DB_CONNECTION_URL =
  "mongodb+srv://rodinshomaf:PDAcy2DCwgVVsyS4@cluster0.mxamktg.mongodb.net/final-project";
